var selectedRow = null;

function onFormSubmit() {
    if (validate()) {
        var formData = readFormData();
        if (selectedRow == null)
            insertNewRecord(formData);
        else
            updateRecord(formData);
        resetForm();
    }
}

function readFormData() {
    var formData = {};
    formData["firstName"] = document.getElementById("firstName").value;
    formData["lastName"] = document.getElementById("lastName").value;
    formData["email"] = document.getElementById("email").value;
    formData["city"] = document.getElementById("city").value;
    formData["country"] = document.getElementById("country").value;
    formData["roomNumber"] = document.getElementById("roomNumber").value;
    formData["checkIn"] = document.getElementById("checkIn").value;
    formData["checkOut"] = document.getElementById("checkOut").value;
    formData["pricePerNight"] = document.getElementById("pricePerNight").value;
    formData["paymentMethod"] = document.getElementById("paymentMethod").value;
    formData["paymentAmount"] = document.getElementById("paymentAmount").value;
    formData["paymentDate"] = document.getElementById("paymentDate").value;
    return formData;
}

function insertNewRecord(data) {
    var table = document.getElementById("bookingList").getElementsByTagName('tbody')[0];
    var newRow = table.insertRow(table.length);

    newRow.insertCell(0).innerHTML = data.firstName + " " + data.lastName;
    newRow.insertCell(1).innerHTML = data.email;
    newRow.insertCell(2).innerHTML = data.city;
    newRow.insertCell(3).innerHTML = data.country;
    newRow.insertCell(4).innerHTML = data.roomNumber;
    newRow.insertCell(5).innerHTML = data.checkIn;
    newRow.insertCell(6).innerHTML = data.checkOut;
    newRow.insertCell(7).innerHTML = data.pricePerNight;
    newRow.insertCell(8).innerHTML = data.paymentMethod;
    newRow.insertCell(9).innerHTML = data.paymentAmount;
    newRow.insertCell(10).innerHTML = data.paymentDate;
    newRow.insertCell(11).innerHTML = `<a onClick="onEdit(this)">Edit</a>
                                       <a onClick="onDelete(this)">Delete</a>`;
}

function resetForm() {
    document.getElementById("firstName").value = "";
    document.getElementById("lastName").value = "";
    document.getElementById("email").value = "";
    document.getElementById("city").value = "";
    document.getElementById("country").value = "";
    document.getElementById("roomNumber").value = "";
    document.getElementById("checkIn").value = "";
    document.getElementById("checkOut").value = "";
    document.getElementById("pricePerNight").value = "";
    document.getElementById("paymentMethod").value = "";
    document.getElementById("paymentAmount").value = "";
    document.getElementById("paymentDate").value = "";
    selectedRow = null;
}

function onEdit(td) {
    selectedRow = td.parentElement.parentElement;
    const fullName = selectedRow.cells[0].innerHTML.split(" ");
    document.getElementById("firstName").value = fullName[0];
    document.getElementById("lastName").value = fullName.slice(1).join(" ");
    document.getElementById("email").value = selectedRow.cells[1].innerHTML;
    document.getElementById("city").value = selectedRow.cells[2].innerHTML;
    document.getElementById("country").value = selectedRow.cells[3].innerHTML;
    document.getElementById("roomNumber").value = selectedRow.cells[4].innerHTML;
    document.getElementById("checkIn").value = selectedRow.cells[5].innerHTML;
    document.getElementById("checkOut").value = selectedRow.cells[6].innerHTML;
    document.getElementById("pricePerNight").value = selectedRow.cells[7].innerHTML;
    document.getElementById("paymentMethod").value = selectedRow.cells[8].innerHTML;
    document.getElementById("paymentAmount").value = selectedRow.cells[9].innerHTML;
    document.getElementById("paymentDate").value = selectedRow.cells[10].innerHTML;
}

function updateRecord(formData) {
    selectedRow.cells[0].innerHTML = formData.firstName + " " + formData.lastName;
    selectedRow.cells[1].innerHTML = formData.email;
    selectedRow.cells[2].innerHTML = formData.city;
    selectedRow.cells[3].innerHTML = formData.country;
    selectedRow.cells[4].innerHTML = formData.roomNumber;
    selectedRow.cells[5].innerHTML = formData.checkIn;
    selectedRow.cells[6].innerHTML = formData.checkOut;
    selectedRow.cells[7].innerHTML = formData.pricePerNight;
    selectedRow.cells[8].innerHTML = formData.paymentMethod;
    selectedRow.cells[9].innerHTML = formData.paymentAmount;
    selectedRow.cells[10].innerHTML = formData.paymentDate;
}

function onDelete(td) {
    if (confirm('Are you sure to delete this record?')) {
        row = td.parentElement.parentElement;
        document.getElementById("bookingList").deleteRow(row.rowIndex);
        resetForm();
    }
}

function validate() {
    isValid = true;
    if (document.getElementById("firstName").value == "") {
        isValid = false;
        document.getElementById("firstNameValidationError").classList.remove("hide");
    } else {
        isValid = true;
        if (!document.getElementById("firstNameValidationError").classList.contains("hide"))
            document.getElementById("firstNameValidationError").classList.add("hide");
    }
    return isValid;
}